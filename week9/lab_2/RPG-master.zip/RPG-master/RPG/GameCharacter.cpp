#include "GameCharacter.h"

GameCharacter::GameCharacter() {
	
}

GameCharacter::GameCharacter(std::string name, float health, float weight, Weapon weapon, Armour armour, int food, CharacterState state) {
	
}

void GameCharacter::SetCharacterName(std::string name) {
	
}

std::string GameCharacter::GetCharacterName() const {
	
}

void GameCharacter::SetCharacterHealth(float health) {
	
}

float GameCharacter::GetCharacterHealth() const {
	
}

void GameCharacter::SetCharacterWeightLimit(float weightLimit) {
	
}

float GameCharacter::GetCharacterWeightLimit() const {
	
}

void GameCharacter::SetCharacterWeapon(Weapon weapon) {
	
}

Weapon GameCharacter::GetCharacterWeapon() const {
	
}

void GameCharacter::SetCharacterArmour(Armour armour) {
	
}

Armour GameCharacter::GetCharacterArmour() const {
	
}

void GameCharacter::SetCharacterFood(int food) {
	
}

int GameCharacter::GetCharacterFood() const {
	
}

void GameCharacter::SetCharacterState(CharacterState state) {
	
}

CharacterState GameCharacter::GetCharacterState() const {
	
}

void GameCharacter::AddFood(int amount) {
	
}

void GameCharacter::Eat() {
	
}

bool GameCharacter::Attack(GameCharacter& character) {
	
}

void GameCharacter::Defend() {
	
}

void GameCharacter::Walk() {
	
}

void GameCharacter::Run() {
	
}

void GameCharacter::Sleep() {
	
}

