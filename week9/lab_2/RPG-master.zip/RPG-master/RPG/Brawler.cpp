#include "Brawler.h"

Brawler::Brawler() {

}

Brawler::Brawler(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int punchDamage, int strength) {
}

void Brawler::SetPunchDamage(int damage) {
	
}

int Brawler::GetPunchDamage() const {
	
}

void Brawler::SetStrength(int strength) {
	
}

int Brawler::GetStrength() const {
	
}

bool Brawler::Attack(GameCharacter& character) {

}

bool Brawler::Brawl(GameCharacter& character) {
	
}

void Brawler::Sleep() {
	
}
