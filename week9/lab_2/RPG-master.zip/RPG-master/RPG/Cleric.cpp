#include "Cleric.h"

Cleric::Cleric() {
	
}

Cleric::Cleric(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int level) {

}

void Cleric::SetPietyLevel(int level) {
	
}

int Cleric::GetPietyLevel() const {
	
}

bool Cleric::Attack(GameCharacter& character) {
	
}

void Cleric::PrayFor(GameCharacter& character) {
	
}

void Cleric::Sleep() {
	
}