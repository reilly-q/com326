#include "BlackWitch.h"

BlackWitch::BlackWitch() {
	
}

BlackWitch::BlackWitch(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int magic, int power) {
}

void BlackWitch::SetMagicProficiency(int magic) {
	
}

int BlackWitch::GetMagicProficiency() const {
	
}

void BlackWitch::SetDarkPower(int power) {
	
}

int BlackWitch::GetDarkPower() const {
	
}

bool BlackWitch::Attack(GameCharacter& character) {
	
}

void BlackWitch::Bewitch(GameCharacter& character) {
	
}

void BlackWitch::Sleep() {
	
}
