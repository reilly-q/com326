#include "Orc.h"

Orc::Orc() {
	
}

Orc::Orc(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int ferocious, int strength) {

}

void Orc::SetFerociousness(int ferocious) {

}

int Orc::GetFerociousness() const {
	
}

void Orc::SetStrength(int strength) {
	
}

int Orc::GetStrength() const {
	
}

bool Orc::Attack(GameCharacter& character) {
	
}

void Orc::Scream(GameCharacter& character) {

}

void Orc::Sleep() {
	
}
