# RPG
* Week 9 Lab Skeleton Code  
Lab 1 solution for class `Item`, `Armour`, and `Weapon` are included in the folder.  
You just need to complete the base class `GameChanger` and the relevant derived character classes.  

* What you need to do ?
1.  Fork the solution into your repo 
2.  Clone using GitKraken or directly in VStudio
3.  When you complete the Additional Challenge, please push to your repo
4.  Send me a message in Discord - I will be able to play your RPG version  
5.  You solution might be selected as next year Week 9 challenge :octocat:

