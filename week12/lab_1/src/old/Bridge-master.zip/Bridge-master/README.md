# Bridge
This is the source file that you need for Week 12 Challenges. We will build a simplified version of the card game Bridge using a custom vector (SmartVector).
