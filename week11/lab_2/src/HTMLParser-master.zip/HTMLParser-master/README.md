# HTMLParser

We are going to create a simple C++ parser that will read a HTML file from a news portal, extract the key HTML elements, and then then produce a summarise document of the news items (heading) and the corresponding links. For this exercise, you can use the sourceNews.html file provided in the github project.
