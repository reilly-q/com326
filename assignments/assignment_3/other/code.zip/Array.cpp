/*
* Array.cpp
*
* Version information
* Author: Dr. Shane Wilson
* Date:09/11/2017
* Description: Rule of Five example using custom array class
*
///**************************************************************************
// * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
// * Pearson Education, Inc. All Rights Reserved.                           *
// *                                                                        *
// * DISCLAIMER: The authors and publisher of this book have used their     *
// * best efforts in preparing the book. These efforts include the          *
// * development, research, and testing of the theories and programs        *
// * to determine their effectiveness. The authors and publisher make       *
// * no warranty of any kind, expressed or implied, with regard to these    *
// * programs or to the documentation contained in these books. The authors *
// * and publisher shall not be liable in any event for incidental or       *
// * consequential damages in connection with, or arising out of, the       *
// * furnishing, performance, or use of these programs.                     *
// **************************************************************************/
// Array class member- and friend-function definitions.
#include <iostream>
#include <iomanip>
#include <stdexcept>

#include "Array.h" // Array class definition
using namespace std;

// default constructor for class Array (default size 10)
Array::Array( int arraySize ) : size( arraySize > 0 ? arraySize : throw invalid_argument("Array size must be greater than 0") ), ptr( new int[ size ] ) {
   for ( size_t i = 0; i < size; i++)
      ptr[ i ] = 0;     // set pointer-based array element
}                       // end Array default constructor

// copy constructor for class Array;
// must receive a reference to an Array

//**TO DO Implement the copy constructor
Array::Array(const Array& inArray) : size{ inArray.size }, ptr{ new int[size] } {
    for (size_t i = 0; i < size; i++)
       ptr[i] = inArray.ptr[i];     // set pointer-based array element
}

//**TO DO implement the move constructor
Array::Array(Array&& inArray) noexcept : size{ inArray.size }, ptr{ inArray.ptr } {
    inArray.size = 0;
    inArray.ptr = nullptr;
}

//**TODO  Implement the destructor
Array::~Array() {
    delete[] ptr;
    ptr = nullptr;
}

// return number of elements of Array
size_t Array::getSize() const
{
   return size; // number of elements in Array
} // end function getSize

//**TO DO overload the assignment operator
const Array& Array::operator=(const Array& inArray) {
    if(inArray != *this) {
        if(size != inArray.size) {
            delete[] ptr;
            size = inArray.size;
            ptr = new int[size];
        }

        for(size_t i = 0; i < size; i++)
            ptr[i] = inArray.ptr[i];     // set pointer-based array element

    }

    return *this;
}

//**TO DO overload the move assignment operator
Array& Array::operator=(Array&& inArray) noexcept {
    if(inArray != *this) {
        delete[] ptr;
        size = inArray.size;
        ptr = inArray.ptr;

        inArray.size = 0;
        inArray.ptr = nullptr;

    }

    return *this;
}

// determine if two Arrays are equal and
// return true, otherwise return false
bool Array::operator==( const Array &right ) const
{
   if ( size != right.size )
      return false; // arrays of different number of elements

   for ( size_t i = 0; i < size; ++i )
      if ( ptr[ i ] != right.ptr[ i ] )
         return false; // Array contents are not equal

   return true; // Arrays are equal
} // end function operator==

// overloaded subscript operator for non-const Arrays;
// reference return creates a modifiable lvalue
int &Array::operator[]( int subscript )
{
   // check for subscript out-of-range error
   if ( subscript < 0 || subscript >= size )
      throw out_of_range( "Subscript out of range" );

   return ptr[ subscript ]; // reference return
} // end function operator[]

// overloaded subscript operator for const Arrays
// const reference return creates an rvalue
int Array::operator[]( int subscript ) const
{
   // check for subscript out-of-range error
   if ( subscript < 0 || subscript >= size )
      throw out_of_range( "Subscript out of range" );

   return ptr[ subscript ]; // returns copy of this element
} // end function operator[]

// overloaded input operator for class Array;
// inputs values for entire Array
istream &operator>>( istream &input, Array &a )
{
   for ( size_t i = 0; i < a.size; ++i )
      input >> a.ptr[ i ];

   return input; // enables cin >> x >> y;
} // end function

// overloaded output operator for class Array
ostream &operator<<( ostream &output, const Array &a )
{
   size_t i;

   // output private ptr-based array
   for ( i = 0; i < a.size; ++i )
   {
      output << setw( 12 ) << a.ptr[ i ];

      if ( ( i + 1 ) % 4 == 0 ) // 4 numbers per row of output
         output << endl;
   } // end for

   if ( i % 4 != 0 ) // end last line of output
      output << endl;

   return output; // enables cout << x << y;
} // end function operator<<
